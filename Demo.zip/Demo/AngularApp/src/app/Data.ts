// Data.ts

export interface Data {
    month: String;
    price: Number;
  }