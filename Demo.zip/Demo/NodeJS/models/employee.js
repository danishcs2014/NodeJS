const mongoose = require('mongoose');

var Employee = mongoose.model('Employee', {
    name: { type: String },
    date: { type: String },
    sale: { type: Number }
});

module.exports = { Employee };